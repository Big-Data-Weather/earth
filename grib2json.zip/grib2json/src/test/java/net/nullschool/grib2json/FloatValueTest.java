package net.nullschool.grib2json;

import org.junit.Test;


/**
 * 2013-10-24<p/>
 *
 * @author Cameron Beccario
 */
public class FloatValueTest {

    @Test
    public void test() {
    }
}
