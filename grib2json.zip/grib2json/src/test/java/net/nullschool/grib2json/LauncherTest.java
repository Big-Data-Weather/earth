package net.nullschool.grib2json;

import org.junit.Test;


/**
 * 2013-10-24<p/>
 *
 * @author Cameron Beccario
 */
public class LauncherTest {

    @Test
    public void test_1() {
//        Launcher.main(new String[] {"c:/users/cambecc/desktop/gfs/gfs.t18z.pgrb2f00", "out.txt", "true"});
//        Launcher.main(new String[] {"c:/users/cambecc/desktop/gfs/gfs.t18z.pgrbf00.2p5deg.grib2", "out.txt", "false"});

//        String args = "--fc 2 --fs 103 --fv 80 --names c:/users/cambecc/desktop/gfs/gfs.t18z.pgrbf00.2p5deg.grib2";
//        Launcher.main(args.split(" "));
    }
}
